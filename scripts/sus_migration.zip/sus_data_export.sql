﻿--
-- PostgreSQL database dump
--

-- Dumped from database version 16.14
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    setting_key character varying(100) NOT NULL,
    setting_value text,
    label character varying(255)
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: class_student_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.class_student_counts (
    id bigint NOT NULL,
    order_item_id bigint NOT NULL,
    class_name character varying(50) NOT NULL,
    boys_count integer DEFAULT 0,
    girls_count integer DEFAULT 0,
    total_count integer DEFAULT 0,
    remarks text
);


--
-- Name: class_student_counts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.class_student_counts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: class_student_counts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.class_student_counts_id_seq OWNED BY public.class_student_counts.id;


--
-- Name: delivery_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_tracking (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    tracking_number character varying(255),
    carrier character varying(100),
    dispatched_at timestamp without time zone,
    delivered_at timestamp without time zone,
    notes text
);


--
-- Name: delivery_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_tracking_id_seq OWNED BY public.delivery_tracking.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: order_admin_edits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_admin_edits (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    edited_by character varying(255) NOT NULL,
    edited_at timestamp without time zone DEFAULT now() NOT NULL,
    summary text
);


--
-- Name: order_admin_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_admin_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_admin_edits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_admin_edits_id_seq OWNED BY public.order_admin_edits.id;


--
-- Name: order_count_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_count_history (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    saved_at timestamp without time zone DEFAULT now() NOT NULL,
    counts_json text NOT NULL
);


--
-- Name: order_count_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_count_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_count_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_count_history_id_seq OWNED BY public.order_count_history.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    product_variant_id bigint,
    total_quantity integer DEFAULT 0,
    unit_price numeric(10,2),
    total_price numeric(12,2),
    notes text
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    school_id bigint NOT NULL,
    order_token character varying(100) NOT NULL,
    order_number character varying(50),
    status character varying(50) DEFAULT 'DRAFT'::character varying,
    total_amount numeric(12,2) DEFAULT 0,
    gst_amount numeric(12,2) DEFAULT 0,
    grand_total numeric(12,2) DEFAULT 0,
    advance_amount numeric(12,2) DEFAULT 0,
    remaining_amount numeric(12,2) DEFAULT 0,
    payment_status character varying(50) DEFAULT 'PENDING'::character varying,
    notes text,
    submitted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    locked boolean DEFAULT false NOT NULL,
    special_discount numeric(12,2) DEFAULT 0.00 NOT NULL
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_type character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    transaction_id character varying(255),
    due_date date,
    paid_at timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    image_url character varying(500) NOT NULL,
    image_type character varying(50) DEFAULT 'FRONT'::character varying,
    sort_order integer DEFAULT 0
);


--
-- Name: product_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_images_id_seq OWNED BY public.product_images.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    size character varying(20),
    color character varying(50),
    price numeric(10,2),
    stock integer DEFAULT 0,
    active boolean DEFAULT true
);


--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: production_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_tracking (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    status character varying(50) NOT NULL,
    notes text,
    updated_by bigint,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: production_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_tracking_id_seq OWNED BY public.production_tracking.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    category_id bigint,
    sub_category_id bigint,
    sku character varying(100),
    description text,
    fabric_type character varying(100),
    color character varying(100),
    gender character varying(20),
    season character varying(50),
    base_price numeric(10,2) DEFAULT 0,
    gst_percent numeric(5,2) DEFAULT 0,
    discount_percent numeric(5,2) DEFAULT 0,
    final_price numeric(10,2) DEFAULT 0,
    size_options character varying(255),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    vendor_id bigint
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: school_catalogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_catalogs (
    id bigint NOT NULL,
    school_id bigint NOT NULL,
    product_id bigint NOT NULL,
    custom_price numeric(10,2),
    active boolean DEFAULT true
);


--
-- Name: school_catalogs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.school_catalogs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: school_catalogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.school_catalogs_id_seq OWNED BY public.school_catalogs.id;


--
-- Name: schools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schools (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    contact_person character varying(255),
    mobile character varying(20),
    email character varying(255),
    address text,
    school_code character varying(50) NOT NULL,
    logo_url character varying(500),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    contact_person_role character varying(100),
    contact_person_2_name character varying(255),
    contact_person_2_role character varying(100),
    contact_person_2_mobile character varying(20),
    contact_person_2_email character varying(255),
    class_names text DEFAULT 'Nursery,Jr. KG,Sr. KG,1st,2nd,3rd,4th,5th,6th,7th,8th,9th,10th'::text
);


--
-- Name: schools_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schools_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schools_id_seq OWNED BY public.schools.id;


--
-- Name: sub_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sub_categories (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    category_id bigint NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: sub_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sub_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sub_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sub_categories_id_seq OWNED BY public.sub_categories.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'SALESMAN'::character varying NOT NULL,
    school_id bigint,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    contact_person character varying(255),
    phone character varying(50),
    email character varying(255),
    address text,
    gst_number character varying(50),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: class_student_counts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_student_counts ALTER COLUMN id SET DEFAULT nextval('public.class_student_counts_id_seq'::regclass);


--
-- Name: delivery_tracking id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_tracking ALTER COLUMN id SET DEFAULT nextval('public.delivery_tracking_id_seq'::regclass);


--
-- Name: order_admin_edits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_admin_edits ALTER COLUMN id SET DEFAULT nextval('public.order_admin_edits_id_seq'::regclass);


--
-- Name: order_count_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_count_history ALTER COLUMN id SET DEFAULT nextval('public.order_count_history_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: product_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images ALTER COLUMN id SET DEFAULT nextval('public.product_images_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: production_tracking id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_tracking ALTER COLUMN id SET DEFAULT nextval('public.production_tracking_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: school_catalogs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_catalogs ALTER COLUMN id SET DEFAULT nextval('public.school_catalogs_id_seq'::regclass);


--
-- Name: schools id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools ALTER COLUMN id SET DEFAULT nextval('public.schools_id_seq'::regclass);


--
-- Name: sub_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories ALTER COLUMN id SET DEFAULT nextval('public.sub_categories_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (setting_key, setting_value, label) FROM stdin;
support_phone	+918275290912	Support Phone Number
support_email	mayur.mehar@gmail.com	Support Email
company_name	kkk	Company / Brand Name
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, active) FROM stdin;
3	Unisex	f
1	Boys	t
2	Girls	t
4	Accessories	t
\.


--
-- Data for Name: class_student_counts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.class_student_counts (id, order_item_id, class_name, boys_count, girls_count, total_count, remarks) FROM stdin;
1	1	Jr. KG	10	0	10	\N
2	2	Jr. KG	10	0	10	\N
3	3	Jr. KG	0	20	20	\N
4	4	Jr. KG	0	20	20	\N
19	5	5th	10	0	10	
20	5	6th	10	0	10	
21	5	7th	10	0	10	
22	5	8th	10	0	10	
23	6	5th	10	0	10	
24	6	6th	10	0	10	
25	6	7th	10	0	10	
26	6	8th	10	0	10	
27	7	5th	0	19	19	
28	7	6th	0	5	5	
29	7	7th	0	5	5	
30	7	8th	0	5	5	
31	8	5th	0	19	19	
32	8	6th	0	5	5	
33	8	7th	0	5	5	
34	8	8th	0	5	5	
\.


--
-- Data for Name: delivery_tracking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_tracking (id, order_id, tracking_number, carrier, dispatched_at, delivered_at, notes) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init schema	SQL	V1__init_schema.sql	1702283196	sususer	2026-05-26 12:24:06.961235	177	t
2	2	dummy data	SQL	V2__dummy_data.sql	-636660671	sususer	2026-05-26 12:24:07.164886	45	t
3	3	fix passwords	SQL	V3__fix_passwords.sql	-1794697833	sususer	2026-05-26 12:34:14.089724	9	t
4	4	convert enums to varchar	SQL	V4__convert_enums_to_varchar.sql	-1638108925	sususer	2026-05-26 13:17:34.255572	107	t
5	5	accessories data	SQL	V5__accessories_data.sql	26690194	sususer	2026-05-26 16:06:32.024658	26	t
6	6	school contact persons	SQL	V6__school_contact_persons.sql	-2089806022	sususer	2026-05-26 16:37:53.075673	12	t
7	7	accessories images	SQL	V7__accessories_images.sql	466413721	sususer	2026-05-26 16:37:53.109868	13	t
8	8	app settings	SQL	V8__app_settings.sql	1960055238	sususer	2026-05-26 16:37:53.136937	20	t
9	9	rename settings columns	SQL	V9__rename_settings_columns.sql	-1635140262	sususer	2026-05-26 16:37:53.171819	5	t
10	10	fix accessories images	SQL	V10__fix_accessories_images.sql	1802784286	sususer	2026-05-26 16:37:53.188876	9	t
11	11	school class names	SQL	V11__school_class_names.sql	1756994394	sususer	2026-05-26 17:06:02.626129	31	t
12	12	order lock and count history	SQL	V12__order_lock_and_count_history.sql	-385162476	sususer	2026-05-26 17:48:57.485944	74	t
13	13	vendors	SQL	V13__vendors.sql	113374000	sususer	2026-05-26 19:28:13.674729	57	t
14	14	order admin edits	SQL	V14__order_admin_edits.sql	-1672966837	sususer	2026-05-26 20:34:51.105179	71	t
15	15	order special discount	SQL	V15__order_special_discount.sql	1103878314	sususer	2026-05-26 20:34:51.2386	14	t
\.


--
-- Data for Name: order_admin_edits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_admin_edits (id, order_id, edited_by, edited_at, summary) FROM stdin;
1	3	admin@sus.com	2026-05-26 20:42:01.823035	Updated notes; GST: 5% â†’ â‚¹2419.20; Item 'White Full-Sleeve Formal Shirt' unit price: â‚¹367.50 â†’ â‚¹368; Item 'White Full-Sleeve Formal Blouse' quantity: 29 â†’ 34; Item 'Navy Blue Box-Pleat Skirt' quantity: 29 â†’ 34
\.


--
-- Data for Name: order_count_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_count_history (id, order_id, saved_at, counts_json) FROM stdin;
1	1	2026-05-26 18:46:28.960618	[{"className":"Jr. KG","boysCount":10,"girlsCount":20}]
2	1	2026-05-26 18:47:04.627339	[{"className":"Jr. KG","boysCount":20,"girlsCount":20}]
3	3	2026-05-26 20:18:56.125906	[{"className":"5th","boysCount":10,"girlsCount":19},{"className":"6th","boysCount":10,"girlsCount":5},{"className":"7th","boysCount":10,"girlsCount":5},{"className":"8th","boysCount":10,"girlsCount":0}]
4	3	2026-05-26 20:23:45.525946	[{"className":"5th","boysCount":10,"girlsCount":19},{"className":"6th","boysCount":10,"girlsCount":5},{"className":"7th","boysCount":10,"girlsCount":4},{"className":"8th","boysCount":10,"girlsCount":0}]
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, product_variant_id, total_quantity, unit_price, total_price, notes) FROM stdin;
1	1	1	\N	10	367.50	3675.00	Uniform A - Boys
2	1	8	\N	10	294.00	2940.00	Uniform A - Boys
3	1	10	\N	20	336.00	6720.00	Uniform A - Girls
4	1	16	\N	20	420.00	8400.00	Uniform A - Girls
6	3	8	\N	40	294.00	11760.00	Uniform A - Boys
5	3	1	\N	40	368.00	14720.00	Uniform A - Boys
7	3	10	\N	34	336.00	11424.00	Uniform A - Girls
8	3	16	\N	34	420.00	14280.00	Uniform A - Girls
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, school_id, order_token, order_number, status, total_amount, gst_amount, grand_total, advance_amount, remaining_amount, payment_status, notes, submitted_at, created_at, updated_at, locked, special_discount) FROM stdin;
1	2	3AB2B8206D8D	ORD-20260526-3AB2B8	DELIVERED	21735.00	1035.00	21735.00	0.00	21735.00	PENDING	CP1: Mayur Mehar | 9876543201 | mayur.mehar@nonstopio.com	2026-05-26 18:46:39.490343	2026-05-26 18:45:46.731328	2026-05-26 20:03:52.71639	t	0.00
3	1	D28AF7B77E53	ORD-20260526-D28AF7	SUBMITTED	52184.00	2484.00	52184.00	0.00	52184.00	PENDING	CP1: Mayur Mehar (Principal) | 9876543201 | mayur.mehar@nonstopio.com	2026-05-26 20:19:05.996847	2026-05-26 20:17:38.286197	2026-05-26 20:42:01.958687	t	0.00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, order_id, amount, payment_type, status, transaction_id, due_date, paid_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, product_id, image_url, image_type, sort_order) FROM stdin;
2	2	/uploads/cb7632d34f2d4a6e9c0a86302a09f342.jpg	FRONT	0
3	3	/uploads/fb8dd9d686b241c5888a2c6db1c2309e.jpg	FRONT	0
4	4	/uploads/ec62841ae9d04d87b7d65161bf9bc756.jpg	FRONT	0
5	5	/uploads/b60b670ca7b347948aec5f71d3c8160e.jpg	FRONT	0
6	6	/uploads/3839d79f99424053aafb4da7f0c064a8.jpg	FRONT	0
7	7	/uploads/43411cadf74a41ff826318b5db84e5ab.jpg	FRONT	0
9	9	/uploads/3c07930d0b834dbeb991ea14b37c0512.jpg	FRONT	0
10	10	/uploads/1cb04365097f4e969481cbcf4a7702d1.jpg	FRONT	0
11	11	/uploads/69ab1e179a28476d870aaa3a57d1eb90.jpg	FRONT	0
12	12	/uploads/0a008f7de8f340be9ce4faff9aa96262.jpg	FRONT	0
13	13	/uploads/efcf16275a564c5dbf3bf8cdc3446a51.jpg	FRONT	0
14	14	/uploads/4f14778eae974d3ab1b108928e5bd50e.jpg	FRONT	0
15	15	/uploads/ad10e148cfdd4ca4aef68720354a0b0c.jpg	FRONT	0
16	16	/uploads/8ecb1701197b476d868e24158ac8dbf2.jpg	FRONT	0
17	17	/uploads/999767c34a3d49ec9f585574112932ed.jpg	FRONT	0
18	18	/uploads/3d921ff7e1be4d6aa17cdff0295eeac6.jpg	FRONT	0
19	8	/uploads/26ffcd56f14148d5b4bac8563c9911b3.jpg	FRONT	0
20	1	/uploads/b5c24aae727a44a39763555c71460ace.jpg	FRONT	0
21	1	/uploads/45b4074174954558a29e413c3da1a8e7.jfif	FRONT	1
22	1	/uploads/4de6be79b112408798f7208902737875.jfif	FRONT	2
23	1	/uploads/41f58ea24b3f403583def8b04b71a10e.jfif	FRONT	3
24	1	/uploads/746496087b9344bb946b927b8dcb6b5e.jfif	FRONT	4
25	1	/uploads/314c5934bc39444babe4f72537c51d9c.jfif	FRONT	5
26	1	/uploads/f43b56852a8e45dd95e4ed449c730ce5.webp	FRONT	6
34	23	https://placehold.co/400x400/292524/ffffff?text=Leather+Belt	FRONT	0
35	24	https://placehold.co/400x400/1e3a8a/ffffff?text=School+Tie	FRONT	0
36	25	https://placehold.co/400x400/172554/ffffff?text=Woven+Belt	FRONT	0
37	26	https://placehold.co/400x400/d97706/ffffff?text=ID+Card+Holder	FRONT	0
38	27	https://placehold.co/400x400/1d4ed8/ffffff?text=Canvas+Belt	FRONT	0
39	22	https://placehold.co/400x400/1e3a8a/ffffff?text=School+Tie	FRONT	0
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, product_id, size, color, price, stock, active) FROM stdin;
\.


--
-- Data for Name: production_tracking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_tracking (id, order_id, status, notes, updated_by, created_at) FROM stdin;
1	1	SUBMITTED	Order submitted by school	\N	2026-05-26 18:46:39.493187
2	1	APPROVED	\N	\N	2026-05-26 19:22:31.97847
3	1	CUTTING	\N	\N	2026-05-26 19:22:35.377185
4	1	STITCHING	\N	\N	2026-05-26 19:22:38.919209
5	1	PACKING	\N	\N	2026-05-26 19:22:44.367923
6	1	DISPATCHED	\N	\N	2026-05-26 19:22:46.640564
7	1	DELIVERED	\N	\N	2026-05-26 19:22:54.034429
8	3	SUBMITTED	Order submitted by school	\N	2026-05-26 20:19:06.00442
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, category_id, sub_category_id, sku, description, fabric_type, color, gender, season, base_price, gst_percent, discount_percent, final_price, size_options, active, created_at, updated_at, vendor_id) FROM stdin;
22	Boys School Tie - Blue Stripe	4	5	ACC-TIE-BOY-001	Boys clip-on school tie, blue and white diagonal stripes.	Polyester	Blue/White	Boys	All Season	110.00	5.00	0.00	115.50	One Size	t	2026-05-26 16:06:32.040043	2026-05-26 19:31:08.322825	4
1	White Full-Sleeve Formal Shirt	1	1	BT-001	Classic white formal shirt with pointed collar and front button placket. Made from breathable cotton, ideal for daily school wear.	Cotton	White	Boys	All Season	350.00	5.00	0.00	367.50	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
2	Light Blue Half-Sleeve Shirt	1	1	BT-002	Light blue half-sleeve school shirt with chest pocket and durable stitching. A popular choice for summer uniforms across Indian schools.	Cotton Blend	Light Blue	Boys	Summer	320.00	5.00	0.00	336.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
3	Navy Blue Polo T-Shirt	1	1	BT-003	Smart navy blue polo tee with ribbed collar and two-button placket. Comfortable for active school days and sports periods.	Cotton Pique	Navy Blue	Boys	All Season	380.00	5.00	5.00	379.05	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
4	V-Neck Woollen Sweater - Boys	1	1	BT-004	Warm V-neck school sweater in navy blue with the standard cut. Suitable for cold mornings and winter season wear.	Wool Blend	Navy Blue	Boys	Winter	750.00	5.00	0.00	787.50	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
5	Full-Zip School Blazer - Boys	1	1	BT-005	Formal school blazer in dark navy with brass buttons and structured fit. Standard for assembly, functions, and winter uniform.	Polyester Wool Blend	Dark Navy	Boys	Winter	1600.00	5.00	10.00	1512.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
6	Grey Formal School Trouser	1	2	BB-001	Classic grey formal trouser with straight cut, elasticated back waist, and reinforced pockets. Designed for durability and comfort.	Polyester Viscose Blend	Grey	Boys	All Season	500.00	5.00	0.00	525.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
7	Navy Blue Formal Trouser	1	2	BB-002	Navy blue flat-front school trouser with side pockets and neat finish. A common uniform staple in CBSE and ICSE schools.	Cotton Blend	Navy Blue	Boys	All Season	520.00	5.00	0.00	546.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
8	Khaki School Short	1	2	BB-003	Khaki half-pant short with elastic waistband and stitched hem. Widely used as summer or junior school uniform in Indian schools.	Cotton	Khaki	Boys	Summer	280.00	5.00	0.00	294.00	4Y,6Y,8Y,10Y,12Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
9	Navy Blue PT Track Pant	1	2	BB-004	Navy blue PT track pant with two side pockets and elastic waistband with drawstring. Standard sportswear for physical education.	Polyester	Navy Blue	Boys	All Season	420.00	5.00	5.00	418.95	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	1
10	White Full-Sleeve Formal Blouse	2	3	GT-001	Crisp white formal blouse with Peter Pan collar and front button opening. A classic staple for girls school uniforms across India.	Cotton	White	Girls	All Season	320.00	5.00	0.00	336.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
11	Light Blue Half-Sleeve Blouse	2	3	GT-002	Comfortable half-sleeve blouse in light blue with neat collar and tuck-in length. Ideal for summer school use.	Cotton Blend	Light Blue	Girls	Summer	300.00	5.00	0.00	315.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
12	Off-White Kurta Top	2	3	GT-003	Straight-cut kurta in off-white with subtle printed border. Designed for schools following traditional Indian dress codes. Fade-resistant.	Cotton	Off White	Girls	All Season	450.00	5.00	0.00	472.50	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
13	V-Neck Woollen Sweater - Girls	2	3	GT-004	Girls navy blue V-neck school sweater in soft wool blend, providing warmth without bulk. Standard winter uniform for junior and senior.	Wool Blend	Navy Blue	Girls	Winter	720.00	5.00	0.00	756.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
14	Girls School Blazer	2	3	GT-005	Tailored school blazer for girls in dark navy with two front buttons and slim fit. Worn for functions, annual days, and formal occasions.	Polyester Wool Blend	Dark Navy	Girls	Winter	1500.00	5.00	10.00	1417.50	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
15	Grey Knife-Pleat Skirt	2	4	GB-001	Grey knife-pleat school skirt with elastic waistband and knee length. Standard uniform style for girls in primary and middle school.	Polyester Viscose Blend	Grey	Girls	All Season	380.00	5.00	0.00	399.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
16	Navy Blue Box-Pleat Skirt	2	4	GB-002	Smart navy blue box-pleat skirt with concealed elastic waistband and durable hem. Widely paired with white or light blue blouses.	Cotton Blend	Navy Blue	Girls	All Season	400.00	5.00	0.00	420.00	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
17	Navy Blue Pinafore Dress	2	4	GB-003	Classic sleeveless pinafore in navy blue with shoulder straps and side zip. Paired over a white blouse, a staple junior girls uniform.	Polyester Cotton	Navy Blue	Girls	All Season	520.00	5.00	5.00	518.70	4Y,6Y,8Y,10Y,12Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
18	White Salwar - Ethnic Set Bottom	2	4	GB-004	Straight-cut white salwar with elastic waistband. Designed to pair with the kurta top for schools with traditional Indian uniform codes.	Cotton	White	Girls	All Season	350.00	5.00	0.00	367.50	4Y,6Y,8Y,10Y,12Y,14Y	t	2026-05-26 09:13:43.889235	2026-05-26 09:13:43.889235	3
23	Boys Leather Belt - Black	4	6	ACC-BLT-BOY-001	Black genuine leather belt for boys, silver buckle.	Leather	Black	Boys	All Season	95.00	5.00	0.00	99.75	S,M,L,XL	t	2026-05-26 16:06:32.040043	2026-05-26 16:06:32.040043	5
24	Girls School Tie - Blue Stripe	4	5	ACC-TIE-GRL-001	Girls clip-on school tie, matching boys pattern.	Polyester	Blue/White	Girls	All Season	110.00	5.00	0.00	115.50	One Size	t	2026-05-26 16:06:32.040043	2026-05-26 16:06:32.040043	5
25	Girls Woven Belt - Navy	4	6	ACC-BLT-GRL-001	Navy woven belt for girls, slim profile with hook clasp.	Woven Fabric	Navy Blue	Girls	All Season	70.00	5.00	0.00	73.50	S,M,L	t	2026-05-26 16:06:32.040043	2026-05-26 16:06:32.040043	5
26	School ID Card Holder	4	7	ACC-IDC-UNI-001	Yellow lanyard with transparent ID card holder.	Nylon/PVC	Yellow	Unisex	All Season	45.00	18.00	0.00	53.10	One Size	t	2026-05-26 16:06:32.040043	2026-05-26 16:06:32.040043	5
27	Canvas Belt - Navy	4	6	ACC-BLT-UNI-001	Navy canvas webbing belt, adjustable metal clasp.	Canvas	Navy Blue	Unisex	All Season	65.00	5.00	0.00	68.25	S,M,L,XL	t	2026-05-26 16:06:32.040043	2026-05-26 16:06:32.040043	5
\.


--
-- Data for Name: school_catalogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_catalogs (id, school_id, product_id, custom_price, active) FROM stdin;
\.


--
-- Data for Name: schools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schools (id, name, contact_person, mobile, email, address, school_code, logo_url, active, created_at, updated_at, contact_person_role, contact_person_2_name, contact_person_2_role, contact_person_2_mobile, contact_person_2_email, class_names) FROM stdin;
2	Samarth Vidyalaya Lakhani	Mayur Mehar	9876543201	mayur.mehar@nonstopio.com	12, MG Road, Pune - 411001	GVPS001	\N	t	2026-05-26 13:56:44.850092	2026-05-26 20:17:05.504451						1st,2nd,3rd,4th
1	My School bhandara	Mayur Mehar	9876543201	mayur.mehar@nonstopio.com	12, MG Road, Pune - 411001	SCH001	\N	t	2026-05-26 08:26:32.402247	2026-05-26 20:17:34.261798						5th,6th,7th,8th
\.


--
-- Data for Name: sub_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sub_categories (id, name, category_id, active) FROM stdin;
1	Topwear	1	t
2	Bottomwear	1	t
3	Topwear	2	t
4	Bottomwear	2	t
5	Tie	4	t
6	Belt	4	t
7	ID Card	4	t
8	Bag	4	t
9	Other	4	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password, role, school_id, active, created_at) FROM stdin;
1	Super Admin	admin@sus.com	$2a$10$N7.nzpG/jgN/8g0MZLTCducZ9W56XpW7i/GE2tSPDXHIkMCLJUyfi	SUPER_ADMIN	\N	t	2026-05-26 12:24:06.977687
2	Ravi Sharma	ravi@sus.com	$2a$10$N7.nzpG/jgN/8g0MZLTCducZ9W56XpW7i/GE2tSPDXHIkMCLJUyfi	SALESMAN	\N	t	2026-05-26 12:24:07.182599
3	Pooja Mehta	pooja@sus.com	$2a$10$N7.nzpG/jgN/8g0MZLTCducZ9W56XpW7i/GE2tSPDXHIkMCLJUyfi	SALESMAN	\N	t	2026-05-26 12:24:07.182599
4	Suresh Kumar	suresh@sus.com	$2a$10$N7.nzpG/jgN/8g0MZLTCducZ9W56XpW7i/GE2tSPDXHIkMCLJUyfi	FACTORY_MANAGER	\N	t	2026-05-26 12:24:07.182599
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, name, contact_person, phone, email, address, gst_number, active, created_at, updated_at) FROM stdin;
1	Rathi Fabrics Pvt Ltd	Suresh Rathi	+91-9876543210	suresh@rathifabrics.com	45, Industrial Area, Surat, Gujarat 395004	24AABCR1234A1Z5	t	2026-05-26 19:28:13.689713	2026-05-26 19:28:13.689713
2	Shree Textile Mills	Anil Sharma	+91-9812345678	anil@shreetextile.com	12, Mill Road, Ahmedabad, Gujarat 380001	24AADCS5678B2Z1	t	2026-05-26 19:28:13.689713	2026-05-26 19:28:13.689713
3	Bombay Uniform House	Priya Patel	+91-9834567890	priya@bombayuniform.com	78, Dharavi Industrial Estate, Mumbai, Maharashtra 400017	27AABCB9012C3Z2	t	2026-05-26 19:28:13.689713	2026-05-26 19:28:13.689713
4	Delhi Stitch Works	Ramesh Gupta	+91-9823456789	ramesh@delhistitchworks.com	33, Okhla Phase II, New Delhi 110020	07AABCD3456D4Z3	t	2026-05-26 19:28:13.689713	2026-05-26 19:28:13.689713
5	KK Accessories Hub	Kavita Krishnan	+91-9845678901	kavita@kkaccessories.com	56, MIDC Industrial Area, Pune, Maharashtra 411019	27AABCK7890E5Z4	t	2026-05-26 19:28:13.689713	2026-05-26 19:28:13.689713
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 4, true);


--
-- Name: class_student_counts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.class_student_counts_id_seq', 34, true);


--
-- Name: delivery_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_tracking_id_seq', 1, false);


--
-- Name: order_admin_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_admin_edits_id_seq', 1, true);


--
-- Name: order_count_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_count_history_id_seq', 4, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 8, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 3, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: product_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_images_id_seq', 39, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 1, false);


--
-- Name: production_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_tracking_id_seq', 8, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 27, true);


--
-- Name: school_catalogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.school_catalogs_id_seq', 1, false);


--
-- Name: schools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schools_id_seq', 2, true);


--
-- Name: sub_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sub_categories_id_seq', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendors_id_seq', 5, true);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (setting_key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: class_student_counts class_student_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_student_counts
    ADD CONSTRAINT class_student_counts_pkey PRIMARY KEY (id);


--
-- Name: delivery_tracking delivery_tracking_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_tracking
    ADD CONSTRAINT delivery_tracking_order_id_key UNIQUE (order_id);


--
-- Name: delivery_tracking delivery_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_tracking
    ADD CONSTRAINT delivery_tracking_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: order_admin_edits order_admin_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_admin_edits
    ADD CONSTRAINT order_admin_edits_pkey PRIMARY KEY (id);


--
-- Name: order_count_history order_count_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_count_history
    ADD CONSTRAINT order_count_history_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_order_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_token_key UNIQUE (order_token);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: production_tracking production_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_tracking
    ADD CONSTRAINT production_tracking_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- Name: school_catalogs school_catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_catalogs
    ADD CONSTRAINT school_catalogs_pkey PRIMARY KEY (id);


--
-- Name: school_catalogs school_catalogs_school_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_catalogs
    ADD CONSTRAINT school_catalogs_school_id_product_id_key UNIQUE (school_id, product_id);


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (id);


--
-- Name: schools schools_school_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_school_code_key UNIQUE (school_code);


--
-- Name: sub_categories sub_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories
    ADD CONSTRAINT sub_categories_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_count_history_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_count_history_order_id ON public.order_count_history USING btree (order_id);


--
-- Name: idx_order_admin_edits_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_admin_edits_order_id ON public.order_admin_edits USING btree (order_id);


--
-- Name: class_student_counts class_student_counts_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.class_student_counts
    ADD CONSTRAINT class_student_counts_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: delivery_tracking delivery_tracking_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_tracking
    ADD CONSTRAINT delivery_tracking_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_admin_edits order_admin_edits_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_admin_edits
    ADD CONSTRAINT order_admin_edits_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_count_history order_count_history_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_count_history
    ADD CONSTRAINT order_count_history_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_items order_items_product_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_variant_id_fkey FOREIGN KEY (product_variant_id) REFERENCES public.product_variants(id);


--
-- Name: orders orders_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: product_images product_images_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: production_tracking production_tracking_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_tracking
    ADD CONSTRAINT production_tracking_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: production_tracking production_tracking_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_tracking
    ADD CONSTRAINT production_tracking_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: products products_sub_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sub_category_id_fkey FOREIGN KEY (sub_category_id) REFERENCES public.sub_categories(id);


--
-- Name: products products_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: school_catalogs school_catalogs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_catalogs
    ADD CONSTRAINT school_catalogs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: school_catalogs school_catalogs_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_catalogs
    ADD CONSTRAINT school_catalogs_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- Name: sub_categories sub_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sub_categories
    ADD CONSTRAINT sub_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: users users_school_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_school_id_fkey FOREIGN KEY (school_id) REFERENCES public.schools(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 7rHgpjscCUqLYwjTDpJ8gCYOfykLtOoKUsCXqKwliY8W8eZ6hKSgihgycbbHUxP



